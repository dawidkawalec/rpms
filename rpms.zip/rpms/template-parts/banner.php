<?php
/**
 * Template part for banner
 *
 */

?>

<section class="banner">
    <div class="container">
        <div class="row">
            <div class="col-lg-12"></div>
        </div>
    </div>
</section>