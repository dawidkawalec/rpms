<?php
/**
* Template Name: Home
 */

get_header(); ?>


<?php get_template_part( 'template-parts/banner');?>



<br>
<br>
<br>
<br>
<br>
<br>
testsssssssssssssssssssss
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil eius consequuntur quos fugit qui aut distinctio
    exercitationem a facere hic veritatis minima non quisquam, atque iusto ab ullam porro, dolore quae. Repellendus,
    praesentium eos necessitatibus non dignissimos tempora sunt sapiente itaque ex natus omnis a dolorum nam quos vero
    ab.</p>

<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusantium ipsam, omnis eligendi repudiandae dolorem modi
    asperiores, temporibus optio eum officia, ipsa provident distinctio. Atque illum est obcaecati, porro earum facilis,
    eos ipsam doloribus quisquam nostrum ullam eveniet ratione explicabo, blanditiis id animi? Quibusdam atque
    reiciendis distinctio consequuntur repellendus vitae officiis, laudantium, nesciunt tenetur eos culpa autem ducimus
    id a? Eum nobis vel sint odio qui harum libero nesciunt voluptatem natus soluta. Magni aspernatur accusantium
    laborum odio consectetur, quis magnam dolores voluptas cumque, placeat similique non, facere quas in? Exercitationem
    soluta eum repudiandae obcaecati, eveniet maxime ab pariatur delectus excepturi quasi earum distinctio unde placeat
    non, voluptates perferendis vero quaerat sapiente culpa corrupti alias veritatis cupiditate! Ipsa quaerat maxime et
    voluptate temporibus ut ullam perspiciatis laboriosam quae at neque voluptatum architecto, deleniti quidem fuga,
    veniam provident voluptatem! Voluptatum inventore eveniet molestiae quasi voluptates non deserunt doloremque, hic
    explicabo? Soluta, nostrum aspernatur.</p>

<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nulla at beatae deserunt ratione hic voluptatum? Omnis
    adipisci natus sapiente fuga temporibus laborum repudiandae et officiis.</p>

<?php
get_footer(); ?>